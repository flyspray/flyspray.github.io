CleanFS
=======

A proposal for a new [Flyspray](http://flyspray.org/) theme.

You can find more info, and discussion on flyspray's [mailing group](http://groups.google.com/group/flyspray/browse_frm/thread/6bcfdfb6d17f92bf)

Usage
-----

- In Flyspray 0.9.9.6:
  - put files in your `/flyspray/themes/` directory
  - overwrite your `/flyspray/templates/` with the new ones (you might want to backup them first)

Credits
-------

- [Blueprint CSS](http://blueprintcss.org) - used for reseting CSS and base typography
- [Iconic](http://somerandomdude.com/work/iconic/) - used for interface icons
