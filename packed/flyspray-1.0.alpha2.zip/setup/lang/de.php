<?php
$translation=array(
'needcomposer'       => 'Flyspray benötigt einige zusätzliche Programmbibliotheken, die mit Composer installiert werden können.',
'installcomposer'    => 'Starte Composer',
'performupgrade'     => 'Aktualisierung durchführen',
'precautions'        => 'Vorsichtsmaßnahmen',
'precautionbackup'   => 'Erstelle eine Sicherung deiner Datenbank und aller zu Flyspray gehörenden Dateien vor der Aktualisierung',
'preconditionchecks' => 'Voraussetzungen',
'upgrade'            => 'Aktualisierung',
'upgradepossible'    => 'Eine Aktualisierung ist möglich.',
'versioncompare'     => 'Deine derzeitige Flysprayversion ist %s und es kann auf Version %s aktualisiert werden.',
'writeaccessconf'    => 'Um Flyspray zu aktualisieren muß Lese- und Schreibrecht für flyspray.conf.php existieren.',
);
?>
