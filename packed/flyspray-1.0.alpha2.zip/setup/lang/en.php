<?php
$language=array(
'needcomposer'       => 'You need some required libraries installed by Composer.',
'installcomposer'    => 'Run Composer',
'performupgrade'     => 'Perform Upgrade',
'precautions'        => 'Precautions',
'precautionbackup'   => 'Create a backup of your database and all Flyspray related files before performing the upgrade.',
'preconditionchecks' => 'Precondition checks',
'upgrade'            => 'Upgrade',
'upgradepossible'    => 'Apparently, an upgrade is possible.',
'versioncompare'     => 'Your current version is %s and the version we can upgrade to is %s.',
'writeaccessconf'    => 'In order to upgrade Flyspray correctly it needs to be able to access and write flyspray.conf.php.',
);
?>
