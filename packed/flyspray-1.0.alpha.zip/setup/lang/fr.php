<?php
$language=array(
'needcomposer'       => 'Vous avez besoin de certaines librairies installées par Composer.',
'installcomposer'    => 'Lancer Composer',
'performupgrade'     => 'Procéder à la mise à jour',
'precautions'        => 'Précautions',
'precautionbackup'   => 'Créez une sauvegarde de  votre base de données ainsi que de tous les fichiers de Flyspray avant tout mise à jour.',
'preconditionchecks' => 'Contrôle des préconditions',
'upgrade'            => 'Mise à jour',
'upgradepossible'    => 'Apparemment la mise à jour n\'est pas possible.',
'versioncompare'     => 'Votre version actuelle est %s et la version vers laquelle nous pouvons mettre à jour est %s.',
'writeaccessconf'    => 'Afin de mettre à jour correctement Flyspray, nous avons besoin d\'accéder en lecture et écriture le fichier flyspray.conf.php.',
);
?>
