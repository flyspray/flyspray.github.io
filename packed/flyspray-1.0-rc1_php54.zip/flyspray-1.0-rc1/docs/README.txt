See also /README.md

Thanks for downloading version 1.x of Flyspray. For installation
instructions, take a look at the INSTALL text file. To upgrade from a
previous version, read the UPGRADING text file.

Flyspray is primarily being developed on Linux (Ubuntu, Debian, OpenSUSE), using Apache 2 and PHP 5 (5.2-5.6)
To report bugs or request features, use the bug tracking system at
http://bugs.flyspray.org/ 

Additional there is a mailing list, see http://flyspray.org/community/mailing-list/

Last thing - We are not responsible if you manage to hose your web server or any
databases by using this software, ok?
